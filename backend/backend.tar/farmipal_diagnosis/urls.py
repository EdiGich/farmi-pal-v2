from django.urls import path

from . import views

urlpatterns = [
    path("diagnose/", views.diagnosis_view, name="diagnosis"),
]
